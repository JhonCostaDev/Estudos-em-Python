import sys
import os
import json

'''
ESTRUTURA DO JSON
{
    'id' = 'A unique identifier for the task',
    'description' = 'A short description of the task',
    'status' = 'The status of the task (todo, in-progress, done)'
    'createdAt': The date and time when the task was created
    'updatedAt': The date and time when the task was last updated
}
'''
# ler o json
def read_json() -> dict:
    file_path = 'data.json'
    if os.path.isfile(file_path):
        print('existe')
        with open(file_path, 'r', encoding='utf-8') as file:
            content = json.load(file)
        
        return content

    else:
        print('criado')
        dictionary = dict()
        with open(file_path, 'w') as file:
            json.dump(dictionary, file, indent=4)
    

def add(user_task):
	print(f'add')
    # task = user_task
    # return task

def update(user_task):
	print(f'update')

def remove(user_task):
    print(f'remove')


if __name__ == "__main__":
    read_json()
    # tasks = {}
    # if len(sys.argv) < 2:
    # 	print('Two argumens are missed')

    # function_name = sys.argv[1]
    # function_args = sys.argv[2]

    # if function_name == 'add':
    # 	add(function_args)
    

    # if function_name == 'update':
    # 	update(function_args)

    # if function_name == 'remove':
    #     remove(function_args)
    