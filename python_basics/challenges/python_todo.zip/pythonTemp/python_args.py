import sys

def say_hello(name='User'):
	print(f'hello {name}')

def say_bye(name='User'):
	print(f'Bye {name}')


if __name__ == "__main__":
    if len(sys.argv) < 2:
    	print('Two argumens are missed')

    function_name = sys.argv[1]
    function_args = sys.argv[2]

    if function_name == 'say_hello':
    	say_hello(function_args)
    # else:
    # 	print('missed args')
    # 	sys.exit(1)

    if function_name == 'say_bye':
    	say_bye(function_args)
    # else:
    # 	print('missed args')
    # 	sys.exit(1)